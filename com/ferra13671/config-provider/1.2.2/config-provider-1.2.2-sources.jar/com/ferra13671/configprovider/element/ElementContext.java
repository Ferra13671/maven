package com.ferra13671.configprovider.element;

import com.google.gson.JsonElement;
import lombok.AllArgsConstructor;

import java.util.function.Consumer;

@AllArgsConstructor
public class ElementContext {
    private final JsonElement element;

    public JsonElement getElementUnsafe() {
        return this.element;
    }

    public <T> T getElementOrDefault(ElementType<T> type, T defaultValue) {
        if (this.element != null && type.equalsFunction().apply(this.element))
            return type.toElementFunction().apply(this.element);
        return defaultValue;
    }

    public <T> void consumeIfPresent(ElementType<T> type, Consumer<T> consumer) {
        if (this.element != null && type.equalsFunction().apply(this.element))
            consumer.accept(type.toElementFunction().apply(this.element));
    }
}
