package com.ferra13671.configprovider.parameter;


import com.ferra13671.configprovider.element.ElementContext;
import com.ferra13671.configprovider.element.ElementType;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public abstract class ParameterImpl<T> implements Parameter {
    @Getter
    private final ElementType<T> type;

    @Override
    public final ElementContext saveToJson() {
        T element = toElement();
        return new ElementContext(type.toJsonFunction().apply(element));
    }

    @Override
    public final void loadFromJson(ElementContext context) {
        context.consumeIfPresent(type, this::fromElement);
    }

    protected abstract T toElement();

    protected abstract void fromElement(T element);
}
