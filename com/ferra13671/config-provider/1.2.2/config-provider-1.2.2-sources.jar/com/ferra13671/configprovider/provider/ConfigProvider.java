package com.ferra13671.configprovider.provider;

import com.ferra13671.configprovider.element.ElementContext;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

public abstract class ConfigProvider {
    public static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    protected Optional<Path> path = Optional.empty();

    public ConfigProvider() {}

    public ConfigProvider(Path defaultPath) {
        this.path = Optional.ofNullable(defaultPath);
    }

    public void load() {
        load(this.path.orElseThrow(() -> new UnsupportedOperationException("Default config path is null")));
    }

    public void load(Path path) {
        InputStream inputStream = null;
        try {
            inputStream = Files.newInputStream(path);
        } catch (Exception e) {
            new Exception("Cannot load config'" + path + "'. Reason: " + e.getMessage()).printStackTrace();
        }
        if (inputStream != null) {
            load(inputStream);
            try {
                inputStream.close();
            } catch (Exception ignored) {}
        }
    }

    public abstract void load(InputStream inputStream);

    public void save() {
        save(this.path.orElseThrow(() -> new UnsupportedOperationException("Default config path is null")));
    }

    public void save(Path path) {
        OutputStream outputStream = null;
        try {
            Files.deleteIfExists(path);
            Files.createDirectories(path.getParent());
            Files.createFile(path);

            outputStream = Files.newOutputStream(path);
        } catch (IOException e) {
            new Exception("Cannot save config'" + path + "'. Reason: " + e.getMessage()).printStackTrace();
        }
        if (outputStream != null) {
            save(outputStream);
            try {
                outputStream.close();
            } catch (Exception ignored) {}
        }
    }

    public abstract void save(OutputStream outputStream);

    protected ElementContext loadFromInput(InputStream inputStream) {
        JsonElement jsonElement = null;
        try {
            jsonElement = JsonParser.parseReader(new InputStreamReader(inputStream));
        } catch (Exception e) {
            new Exception("Cannot load jsonElement from input stream. Reason: " + e.getMessage()).printStackTrace();
        }
        return new ElementContext(jsonElement);
    }
}
