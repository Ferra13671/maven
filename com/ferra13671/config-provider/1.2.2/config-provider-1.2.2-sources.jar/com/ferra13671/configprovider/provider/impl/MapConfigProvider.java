package com.ferra13671.configprovider.provider.impl;

import com.ferra13671.configprovider.element.ElementContext;
import com.ferra13671.configprovider.element.ElementType;
import com.ferra13671.configprovider.parameter.Parameter;
import com.ferra13671.configprovider.provider.ConfigProvider;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.HashMap;

public class MapConfigProvider extends ConfigProvider {
    private final HashMap<String, Parameter> parameters;

    public MapConfigProvider(Path defaultPath, HashMap<String, Parameter> parameters) {
        super(defaultPath);
        this.parameters = parameters;
    }

    public MapConfigProvider(HashMap<String, Parameter> parameters) {
        super(null);
        this.parameters = parameters;
    }

    @Override
    public void load(InputStream inputStream) {
        JsonElement jsonElement = loadFromInput(inputStream).getElementUnsafe();

        if (jsonElement != null && ElementType.JSON_OBJECT.equalsFunction().apply(jsonElement))
            this.parameters.forEach((name, parameter) ->
                parameter.loadFromJson(new ElementContext(
                        ElementType.JSON_OBJECT.toElementFunction().apply(jsonElement).get(name)
                ))
            );
    }

    @Override
    public void save(OutputStream outputStream) {
        JsonObject jsonObject = new JsonObject();

        this.parameters.forEach((name, parameter) -> {
            JsonElement jsonElement = parameter.saveToJson().getElementUnsafe();
            if (jsonElement != null)
                jsonObject.add(name, jsonElement);
        });

        try(OutputStreamWriter writer = new OutputStreamWriter(outputStream, StandardCharsets.UTF_8)) {
            writer.write(GSON.toJson(jsonObject));
        } catch (Exception e) {
            new Exception("Cannot save config. Reason: " + e.getMessage()).printStackTrace();
        }
    }
}
