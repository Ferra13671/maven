package com.ferra13671.configprovider.provider.impl;

import com.ferra13671.configprovider.element.ElementContext;
import com.ferra13671.configprovider.parameter.Parameter;
import com.ferra13671.configprovider.provider.ConfigProvider;
import com.google.gson.JsonElement;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

public class ObjectConfigProvider extends ConfigProvider {
    private final Parameter parameter;

    public ObjectConfigProvider(Path defaultPath, Parameter parameter) {
        super(defaultPath);
        this.parameter = parameter;
    }

    public ObjectConfigProvider(Parameter parameter) {
        super(null);
        this.parameter = parameter;
    }

    @Override
    public void load(InputStream inputStream) {
        JsonElement jsonElement = loadFromInput(inputStream).getElementUnsafe();

        if (jsonElement != null && this.parameter.getType().equalsFunction().apply(jsonElement))
            this.parameter.loadFromJson(new ElementContext(jsonElement));
    }

    @Override
    public void save(OutputStream outputStream) {
        JsonElement jsonElement = this.parameter.saveToJson().getElementUnsafe();

        if (jsonElement != null)
            try (OutputStreamWriter writer = new OutputStreamWriter(outputStream, StandardCharsets.UTF_8)) {
                writer.write(GSON.toJson(jsonElement));
            } catch (Exception e) {
                new Exception("Cannot save config. Reason: " + e.getMessage()).printStackTrace();
            }
    }
}
