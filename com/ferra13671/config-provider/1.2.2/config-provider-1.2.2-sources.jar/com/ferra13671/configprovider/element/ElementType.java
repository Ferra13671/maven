package com.ferra13671.configprovider.element;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

import java.util.function.Function;

public record ElementType<T>(Function<JsonElement, Boolean> equalsFunction, Function<JsonElement, T> toElementFunction, Function<T, JsonElement> toJsonFunction) {

    public static final ElementType<JsonObject> JSON_OBJECT = new ElementType<>(JsonElement::isJsonObject, JsonElement::getAsJsonObject, element -> element);
    public static final ElementType<JsonArray> JSON_ARRAY = new ElementType<>(JsonElement::isJsonArray, JsonElement::getAsJsonArray, element -> element);
    public static final ElementType<Boolean> BOOLEAN = new ElementType<>(jsonElement -> {
        if (jsonElement instanceof JsonPrimitive primitive)
            return primitive.isBoolean();
        return false;
    }, jsonElement -> jsonElement.getAsJsonPrimitive().getAsBoolean(), JsonPrimitive::new);
    public static final ElementType<String> STRING = new ElementType<>(jsonElement -> {
        if (jsonElement instanceof JsonPrimitive primitive)
            return primitive.isString();
        return false;
    }, jsonElement -> jsonElement.getAsJsonPrimitive().getAsString(), JsonPrimitive::new);
    public static final ElementType<Number> NUMBER = new ElementType<>(jsonElement -> {
        if (jsonElement instanceof JsonPrimitive primitive)
            return primitive.isNumber();
        return false;
    }, jsonElement -> jsonElement.getAsJsonPrimitive().getAsNumber(), JsonPrimitive::new);
}
