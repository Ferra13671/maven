package com.ferra13671.configprovider.parameter;

import com.ferra13671.configprovider.element.ElementContext;
import com.ferra13671.configprovider.element.ElementType;

public interface Parameter {

    ElementType<?> getType();

    ElementContext saveToJson();

    void loadFromJson(ElementContext context);
}
