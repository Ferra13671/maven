package com.ferra13671.cometrenderer.plugins.posteffects;

import com.ferra13671.cometrenderer.CometRenderer;
import com.ferra13671.cometrenderer.buffer.framebuffer.Framebuffer;
import com.ferra13671.cometrenderer.buffer.framebuffer.FramebufferImpl;
import com.ferra13671.cometrenderer.buffer.framebuffer.FramebufferInfo;
import com.ferra13671.cometrenderer.vertex.DrawMode;
import com.ferra13671.cometrenderer.vertex.format.VertexFormat;
import org.apiguardian.api.API;

import java.awt.*;
import java.util.HashMap;
import java.util.List;

@API(status = API.Status.MAINTAINED)
public class PostEffectPipeline {
    private final List<LocalFrameBufferInfo> localFrameBuffers;
    private final List<ProgramPass> passes;

    public PostEffectPipeline(List<LocalFrameBufferInfo> localFrameBuffers, List<ProgramPass> passes) {
        this.localFrameBuffers = localFrameBuffers;
        this.passes = passes;
    }

    public void execute(int textureWidth, int textureHeight) {
        HashMap<String, Framebuffer> frameBuffers = new HashMap<>();
        for (LocalFrameBufferInfo info : localFrameBuffers) {
            FramebufferImpl f = new FramebufferImpl(
                    FramebufferInfo.builder()
                            .name(info.name())
                            .useDepth(false)
                            .width(textureWidth)
                            .height(textureHeight)
                            .clearColor(new Color(info.clearColor()))
                            .build()
            );
            f.clearColor();
            frameBuffers.put(info.name(), f);
        }

        PostEffectContext context = new PostEffectContext(CometRenderer.createMesh(DrawMode.QUADS, VertexFormat.POSITION, builder -> {
            builder.vertex(0f, textureHeight, 0f);
            builder.vertex(textureWidth, textureHeight, 0f);
            builder.vertex(textureWidth, 0, 0f);
            builder.vertex(0f, 0f, 0f);
        }), frameBuffers);

        for (ProgramPass pass : passes)
            pass.execute(context);

        context.mesh().close();
        for (Framebuffer f : context.framebuffers().values())
            f.delete();
    }

    public static PostEffectPipelineBuilder builder() {
        return new PostEffectPipelineBuilder();
    }
}
