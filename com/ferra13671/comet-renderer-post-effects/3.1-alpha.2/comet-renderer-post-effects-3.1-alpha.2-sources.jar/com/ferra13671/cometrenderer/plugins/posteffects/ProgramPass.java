package com.ferra13671.cometrenderer.plugins.posteffects;

import com.ferra13671.cometrenderer.CometRenderer;
import com.ferra13671.cometrenderer.buffer.framebuffer.Framebuffer;
import com.ferra13671.cometrenderer.glsl.Program;
import com.ferra13671.cometrenderer.utils.Pair;
import org.apiguardian.api.API;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

@API(status = API.Status.MAINTAINED)
public class ProgramPass {
    private final Program program;
    private final List<Pair<Integer, Function<PostEffectContext, Framebuffer>>> inputs;
    private final Function<PostEffectContext, Framebuffer> output;
    private final Consumer<Program> preRenderConsumer;

    public ProgramPass(Program program, List<Pair<Integer, Function<PostEffectContext, Framebuffer>>> inputs, Function<PostEffectContext, Framebuffer> output, Consumer<Program> preRenderConsumer) {
        this.program = program;
        this.inputs = inputs;
        this.output = output;
        this.preRenderConsumer = preRenderConsumer;
    }

    public void execute(PostEffectContext context) {
        Framebuffer outputFrameBuffer = output.apply(context);
        outputFrameBuffer.bind(true);

        CometRenderer.setCurrentProgram(program);
        for (Pair<Integer, Function<PostEffectContext, Framebuffer>> input : inputs)
            program.getSampler(input.left()).setTextureSampler(input.right().apply(context).getColorTextureId(), 0);
        preRenderConsumer.accept(program);

        CometRenderer.draw(context.mesh(), false);
    }

    public static ProgramPassBuilder builder() {
        return new ProgramPassBuilder();
    }
}
