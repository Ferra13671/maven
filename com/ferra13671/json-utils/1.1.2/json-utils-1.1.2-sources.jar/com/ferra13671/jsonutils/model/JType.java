package com.ferra13671.jsonutils.model;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

public record JType<T>(Function<JElement, Boolean> equalsFunction, Function<JElement, T> toElementFunction, Function<T, JElement> toJsonFunction) {

    public static final JType<JValue> JVALUE = new JType<>(
            element -> element instanceof JValue,
            element -> (JValue) element,
            value -> value
    );

    public static final JType<JObject> JOBJECT = new JType<>(
            element -> element instanceof JObject,
            element -> (JObject) element,
            object -> object
    );

    public static final JType<JArray> JARRAY = new JType<>(
            element -> element instanceof JArray,
            element -> (JArray) element,
            array -> array
    );

    public static final JType<Boolean> BOOLEAN = new JType<>(
            element -> element instanceof JValue value && value.isBoolean(),
            element -> ((JValue) element).getAsBoolean(),
            JValue::new
    );

    public static final JType<Number> NUMBER = new JType<>(
            element -> element instanceof JValue value && value.isNumber(),
            element ->  ((JValue) element).getAsNumber(),
            JValue::new
    );

    public static final JType<String> STRING = new JType<>(
            element -> element instanceof JValue value && value.isString(),
            element -> ((JValue) element).getAsString(),
            JValue::new
    );

    public static  <T extends Enum<?>> JType<T> ENUM(Class<T> clazz) {
        return (JType<T>) ENUM_ELEMENT_TYPES.apply((Class<Enum<?>>) clazz);
    }



    private static final Function<Class<Enum<?>>, JType<Enum<?>>> ENUM_ELEMENT_TYPES = new Function<>() {
        private final Map<Class<Enum<?>>, JType<Enum<?>>> cache = new ConcurrentHashMap<>();

        @Override
        public JType<Enum<?>> apply(Class<Enum<?>> clazz) {
            return this.cache.computeIfAbsent(clazz, c -> new JType<>(
                    element -> {
                        if (element instanceof JValue value) {
                            for (Enum<?> e : c.getEnumConstants())
                                if (e.name().equals(value.getAsString()))
                                    return true;
                        }
                        return false;
                    },
                    element -> toEnum(((JValue) element).getAsString(), c),
                    _enum -> new JValue(_enum.name())
            ));
        }
    };

    private static <T extends Enum<?>> T toEnum(String name, Class<T> clazz) {
        for (Enum<?> e : clazz.getEnumConstants())
            if (e.name().equals(name))
                return (T) e;

        return null;
    }
}
