package com.ferra13671.jsonutils.model;

import lombok.AllArgsConstructor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@AllArgsConstructor
public class JArray extends JElement implements Iterable<JElement> {
    private final List<JElement> elements;

    public JArray() {
        this(new ArrayList<>());
    }

    @Override
    public Iterator<JElement> iterator() {
        return this.elements.iterator();
    }

    public List<JElement> asList() {
        return this.elements;
    }

    public void add(JElement element) {
        this.elements.add(element);
    }

    public <T> void add(JType<T> type, T value) {
        add(type.toJsonFunction().apply(value));
    }

    public void add(int index, JElement element) {
        this.elements.add(index, element);
    }

    public <T> void add(int index, JType<T> type, T value) {
        add(index, type.toJsonFunction().apply(value));
    }

    public void set(int index, JElement element) {
        this.elements.set(index, element);
    }

    public <T> void set(int index, JType<T> type, T value) {
        set(index, type.toJsonFunction().apply(value));
    }

    public void remove(JElement element) {
        this.elements.remove(element);
    }

    public <T> void remove(JType<T> type, T value) {
        remove(type.toJsonFunction().apply(value));
    }

    public void remove(int index) {
        this.elements.remove(index);
    }

    public void addAll(JArray array) {
        this.elements.addAll(array.elements);
    }

    public boolean contains(JElement element) {
        return this.elements.contains(element);
    }

    public <T> boolean contains(JType<T> type, T value) {
        return contains(type.toJsonFunction().apply(value));
    }

    public JElement get(int index) {
        return index < this.elements.size() ? this.elements.get(index) : new JElement();
    }

    public <T> T get(int index, JType<T> type, T defaultValue) {
        return get(index).cast(type, defaultValue);
    }

    public int size() {
        return this.elements.size();
    }

    public boolean isEmpty() {
        return this.elements.isEmpty();
    }

    @Override
    public int hashCode() {
        return this.elements.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof JArray array && this.elements.equals(array.elements);
    }
}
