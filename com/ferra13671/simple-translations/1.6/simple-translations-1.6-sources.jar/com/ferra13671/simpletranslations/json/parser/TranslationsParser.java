package com.ferra13671.simpletranslations.json.parser;

import com.ferra13671.jsonutils.model.*;
import lombok.NonNull;
import lombok.experimental.UtilityClass;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;

@UtilityClass
public class TranslationsParser {

    public Map<String, String> parse(InputStream inputStream, JFormat format) {
        if (inputStream != null) {
            try (Reader reader = new InputStreamReader(inputStream)) {
                JElement element = format != null ? JModel.read(reader, format) : JModel.read(reader);

                return PatternProcessor.processTranslations(getRawTranslations(
                        element instanceof JObject object ? object : null,
                        new HashMap<>(),
                        new TranslationId("")
                ));
            } catch (Exception e) {
                e.printStackTrace();

                return new HashMap<>();
            }
        } else
            return new HashMap<>();
    }

    public Map<String, String> parse(InputStream inputStream) {
        return parse(inputStream, null);
    }

    public Map<String, String> parse(JObject jObject) {
        return PatternProcessor.processTranslations(getRawTranslations(
                jObject,
                new HashMap<>(),
                new TranslationId("")
        ));
    }

    Map<TranslationId, String> getRawTranslations(JObject jObject, @NonNull Map<TranslationId, String> translations, @NonNull TranslationId prefix) {
        if (jObject != null) {
            jObject.forEach((name, element) -> {
                TranslationId id = new TranslationId(prefix.id().isEmpty() ? name : name.isEmpty() ? prefix.id() : String.join(".", prefix.id(), name));

                element.consumeIfExtends(JType.STRING, s -> translations.put(id, s));

                element.consumeIfExtends(JType.JARRAY, array -> {
                    StringBuilder builder = new StringBuilder();

                    array.forEach(e ->
                        e.consumeIfExtends(JType.STRING, s -> builder.append(s).append("\n"))
                    );

                    if (!builder.isEmpty())
                        builder.deleteCharAt(builder.length() - 1);

                    translations.put(id, builder.toString());
                });

                element.consumeIfExtends(JType.JOBJECT, object -> getRawTranslations(object, translations, id));
            });
        }

        return translations;
    }
}
