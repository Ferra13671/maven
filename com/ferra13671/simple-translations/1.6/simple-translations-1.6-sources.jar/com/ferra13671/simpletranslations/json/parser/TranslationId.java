package com.ferra13671.simpletranslations.json.parser;

public record TranslationId(String id) {

    public TranslationId getParent() {
        String[] elements = this.id.split("\\.");

        if (elements.length > 1) {
            String[] parentElements = new String[elements.length - 1];
            System.arraycopy(elements, 0, parentElements, 0, parentElements.length);

            return new TranslationId(String.join(".", parentElements));
        } else
            return new TranslationId("");
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof TranslationId(String id1) && id1.equals(this.id);
    }
}
