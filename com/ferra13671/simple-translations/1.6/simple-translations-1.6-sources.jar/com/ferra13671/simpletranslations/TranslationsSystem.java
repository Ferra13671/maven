package com.ferra13671.simpletranslations;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

@RequiredArgsConstructor
public class TranslationsSystem {
    private final HashMap<String, HashMap<String, String>> languages = new HashMap<>();
    @NonNull
    private final Supplier<String> languageGetter;
    @NonNull
    private final String defaultLanguage;

    public String translate(String id) {
        return this.languages.getOrDefault(
                this.languageGetter.get(),
                this.languages.computeIfAbsent(
                        this.defaultLanguage,
                        l -> new HashMap<>()
                )
        )
                .getOrDefault(id, id);
    }

    public String translate(String id, String... args) {
        return String.format(translate(id), args);
    }

    public void addTranslations(String languageName, Map<String, String> translations) {
        this.languages.computeIfAbsent(languageName, l -> new HashMap<>())
                .putAll(translations);
    }
}
