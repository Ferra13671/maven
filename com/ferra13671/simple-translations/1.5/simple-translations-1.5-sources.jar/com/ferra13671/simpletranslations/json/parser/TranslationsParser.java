package com.ferra13671.simpletranslations.json.parser;

import com.ferra13671.simpletranslations.json.model.JObject;
import lombok.NonNull;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public abstract class TranslationsParser<T> {

    public Map<String, String> parse(@NonNull InputStream inputStream) {
        try {
            return PatternProcessor.processTranslations(getRawTranslations(
                    parseObject(inputStream),
                    new HashMap<>(),
                    new TranslationId("")
            ));
        } catch (Exception e) {
            e.printStackTrace();

            return new HashMap<>();
        }
    }

    public Map<String, String> parse(@NonNull T jsonObject) {
        return PatternProcessor.processTranslations(getRawTranslations(
                parseObject(jsonObject),
                new HashMap<>(),
                new TranslationId("")
        ));
    }

    protected abstract JObject parseObject(@NonNull InputStream inputStream);

    protected abstract JObject parseObject(T jsonObject);

    Map<TranslationId, String> getRawTranslations(JObject jsonObject, @NonNull Map<TranslationId, String> translations, @NonNull TranslationId prefix) {
        if (jsonObject != null) {
            jsonObject.forEach((name, element) -> {
                TranslationId id = new TranslationId(prefix.id().isEmpty() ? name : name.isEmpty() ? prefix.id() : String.join(".", prefix.id(), name));

                if (element.isString())
                    translations.put(id, element.asString());

                if (element.isJArray()) {
                    StringBuilder builder = new StringBuilder();

                    element.asJArray().forEach(e -> {
                        if (e.isString())
                            builder.append(e.asString() + "\n");
                    });

                    if (!builder.isEmpty())
                        builder.deleteCharAt(builder.length() - 1);

                    translations.put(id, builder.toString());
                }

                if (element.isJObject())
                    getRawTranslations(element.asJObject(), translations, id);
            });
        }

        return translations;
    }
}
