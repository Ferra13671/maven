package com.ferra13671.simpletranslations.json.model;

import java.util.function.BiConsumer;

public interface JObject {

    void forEach(BiConsumer<String, JElement> consumer);
}
