package com.ferra13671.simpletranslations.json.model;

import java.util.function.Consumer;

public interface JArray {

    void forEach(Consumer<JElement> consumer);
}
