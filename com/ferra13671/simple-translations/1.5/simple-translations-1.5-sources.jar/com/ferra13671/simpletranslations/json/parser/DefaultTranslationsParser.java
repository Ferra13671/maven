package com.ferra13671.simpletranslations.json.parser;

import com.ferra13671.simpletranslations.json.model.JArray;
import com.ferra13671.simpletranslations.json.model.JElement;
import com.ferra13671.simpletranslations.json.model.JObject;
import com.google.gson.*;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

class DefaultTranslationsParser extends TranslationsParser<JsonObject> {

    @Override
    protected JObject parseObject(@NonNull InputStream inputStream) {
        try(InputStreamReader reader = new InputStreamReader(inputStream)) {
            return new DefaultJsonObject(JsonParser.parseReader(reader).getAsJsonObject());
        } catch (Exception e) {
            e.printStackTrace();

            return null;
        }
    }

    @Override
    protected JObject parseObject(JsonObject jsonObject) {
        return new DefaultJsonObject(jsonObject);
    }

    @RequiredArgsConstructor
    static class DefaultJsonObject implements JObject {
        private final JsonObject object;

        @Override
        public void forEach(BiConsumer<String, JElement> consumer) {
            this.object.asMap().forEach((s, element) -> consumer.accept(s, new DefaultJsonElement(element)));
        }
    }

    @RequiredArgsConstructor
    static class DefaultJsonArray implements JArray {
        private final JsonArray array;

        @Override
        public void forEach(Consumer<JElement> consumer) {
            this.array.forEach(element -> consumer.accept(new DefaultJsonElement(element)));
        }
    }

    @RequiredArgsConstructor
    static class DefaultJsonElement implements JElement {
        private final JsonElement element;

        @Override
        public boolean isJObject() {
            return this.element.isJsonObject();
        }

        @Override
        public JObject asJObject() {
            return new DefaultJsonObject(this.element.getAsJsonObject());
        }

        @Override
        public boolean isJArray() {
            return this.element.isJsonArray();
        }

        @Override
        public JArray asJArray() {
            return new DefaultJsonArray(this.element.getAsJsonArray());
        }

        @Override
        public boolean isString() {
            return this.element instanceof JsonPrimitive primitive && primitive.isString();
        }

        @Override
        public String asString() {
            return this.element.getAsString();
        }
    }
}
