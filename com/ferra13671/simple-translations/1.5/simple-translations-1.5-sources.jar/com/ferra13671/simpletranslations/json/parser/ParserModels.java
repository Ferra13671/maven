package com.ferra13671.simpletranslations.json.parser;

import com.google.gson.JsonObject;
import de.marhali.json5.Json5Object;
import lombok.experimental.UtilityClass;

@UtilityClass
public class ParserModels {
    public final TranslationsParser<JsonObject> JSON = new DefaultTranslationsParser();
    public final TranslationsParser<Json5Object> JSON5 = new Json5TranslationsParser();
    public final TranslationsParser<org.hjson.JsonObject> HJSON = new HJsonTranslationsParser();
}
