package com.ferra13671.simpletranslations.json.parser;

import com.ferra13671.simpletranslations.json.model.JArray;
import com.ferra13671.simpletranslations.json.model.JElement;
import com.ferra13671.simpletranslations.json.model.JObject;
import de.marhali.json5.*;
import de.marhali.json5.stream.Json5Lexer;
import de.marhali.json5.stream.Json5Parser;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class Json5TranslationsParser extends TranslationsParser<Json5Object> {

    @Override
    protected JObject parseObject(@NonNull InputStream inputStream) {
        try(InputStreamReader reader = new InputStreamReader(inputStream)) {
            return new J5Object(Json5Parser.parseObject(new Json5Lexer(reader, Json5Options.DEFAULT)));
        } catch (Exception e) {
            e.printStackTrace();

            return null;
        }
    }

    @Override
    protected JObject parseObject(Json5Object jsonObject) {
        return new J5Object(jsonObject);
    }

    @RequiredArgsConstructor
    static class J5Object implements JObject {
        private final Json5Object object;

        @Override
        public void forEach(BiConsumer<String, JElement> consumer) {
            this.object.entrySet().forEach(entry -> consumer.accept(entry.getKey(), new J5Element(entry.getValue())));
        }
    }

    @RequiredArgsConstructor
    static class J5Array implements JArray {
        private final Json5Array array;

        @Override
        public void forEach(Consumer<JElement> consumer) {
            this.array.forEach(element -> consumer.accept(new J5Element(element)));
        }
    }

    @RequiredArgsConstructor
    static class J5Element implements JElement {
        private final Json5Element element;

        @Override
        public boolean isJObject() {
            return this.element.isJsonObject();
        }

        @Override
        public JObject asJObject() {
            return new J5Object(this.element.getAsJsonObject());
        }

        @Override
        public boolean isJArray() {
            return this.element.isJsonArray();
        }

        @Override
        public JArray asJArray() {
            return new J5Array(this.element.getAsJsonArray());
        }

        @Override
        public boolean isString() {
            return this.element instanceof Json5Primitive primitive && primitive.isString();
        }

        @Override
        public String asString() {
            return this.element.getAsString();
        }
    }
}
