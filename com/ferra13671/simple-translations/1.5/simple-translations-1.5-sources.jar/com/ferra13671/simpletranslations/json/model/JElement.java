package com.ferra13671.simpletranslations.json.model;

public interface JElement {

    boolean isJObject();

    JObject asJObject();

    boolean isJArray();

    JArray asJArray();

    boolean isString();

    String asString();
}
