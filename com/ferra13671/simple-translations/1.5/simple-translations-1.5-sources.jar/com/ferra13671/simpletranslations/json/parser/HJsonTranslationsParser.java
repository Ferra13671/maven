package com.ferra13671.simpletranslations.json.parser;

import com.ferra13671.simpletranslations.json.model.JArray;
import com.ferra13671.simpletranslations.json.model.JElement;
import com.ferra13671.simpletranslations.json.model.JObject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.hjson.JsonArray;
import org.hjson.JsonObject;
import org.hjson.JsonValue;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class HJsonTranslationsParser extends TranslationsParser<JsonObject> {

    @Override
    protected JObject parseObject(@NonNull InputStream inputStream) {
        try(InputStreamReader reader = new InputStreamReader(inputStream)) {
            return new HJObject(JsonObject.readHjson(reader).asObject());
        } catch (Exception e) {
            e.printStackTrace();

            return null;
        }
    }

    @Override
    protected JObject parseObject(JsonObject jsonObject) {
        return new HJObject(jsonObject);
    }

    @RequiredArgsConstructor
    static class HJObject implements JObject {
        private final JsonObject object;

        @Override
        public void forEach(BiConsumer<String, JElement> consumer) {
            this.object.forEach(member -> consumer.accept(member.getName(), new HJElement(member.getValue())));
        }
    }

    @RequiredArgsConstructor
    static class HJArray implements JArray {
        private final JsonArray array;

        @Override
        public void forEach(Consumer<JElement> consumer) {
            this.array.forEach(value -> consumer.accept(new HJElement(value)));
        }
    }

    @RequiredArgsConstructor
    static class HJElement implements JElement {
        private final JsonValue element;

        @Override
        public boolean isJObject() {
            return this.element.isObject();
        }

        @Override
        public JObject asJObject() {
            return new HJObject(this.element.asObject());
        }

        @Override
        public boolean isJArray() {
            return this.element.isArray();
        }

        @Override
        public JArray asJArray() {
            return new HJArray(this.element.asArray());
        }

        @Override
        public boolean isString() {
            return this.element.isString();
        }

        @Override
        public String asString() {
            return this.element.asString();
        }
    }
}
