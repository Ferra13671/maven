package com.ferra13671.simplelanguagesystem;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import lombok.NonNull;
import lombok.experimental.UtilityClass;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@UtilityClass
public class TranslationsParser {
    private final Pattern formatPattern = Pattern.compile("\\$\\{id\\h*=\\h*(?<id>[^{}]*)}");

    public Map<String, String> parse(@NonNull InputStream inputStream) {
        try(InputStreamReader reader = new InputStreamReader(inputStream)) {
            return formatTranslations(getRawTranslations(
                    JsonParser.parseReader(reader).getAsJsonObject(),
                    new HashMap<>(),
                    ""
            ));
        } catch (Exception e) {
            e.printStackTrace();

            return new HashMap<>();
        }
    }

    public Map<String, String> parse(@NonNull JsonObject jsonObject) {
        return formatTranslations(getRawTranslations(
                jsonObject,
                new HashMap<>(),
                ""
        ));
    }

    private Map<String, String> getRawTranslations(@NonNull JsonObject jsonObject, @NonNull Map<String, String> translations, @NonNull String prefix) {
        jsonObject.asMap().forEach((name, element) -> {
            String id = prefix.isEmpty() ? name : name.isEmpty() ? prefix : String.join(".", prefix, name);

            if (element instanceof JsonPrimitive primitive && primitive.isString())
                translations.put(id, primitive.getAsString());

            if (element instanceof JsonObject object)
                getRawTranslations(object, translations, id);
        });

        return translations;
    }


    private Map<String, String> formatTranslations(Map<String, String> translations) {
        Map<String, String> formattedTranslations = new HashMap<>();

        translations.keySet().forEach(id -> formatTranslation(id, formattedTranslations, translations));

        return formattedTranslations;
    }

    private void formatTranslation(String id, Map<String, String> formattedTranslations, Map<String, String> translations) {
        if (formattedTranslations.containsKey(id))
            return;

        String value = translations.get(id);

        Matcher matcher = formatPattern.matcher(value);
        for (MatchResult result : matcher.results().toList()) {
            String formatId = result.group("id");

            if (translations.containsKey(formatId)) {
                if (!formattedTranslations.containsKey(formatId))
                    formatTranslation(formatId, formattedTranslations, translations);

                value = value.replace(result.group(), formattedTranslations.get(formatId));
            }
        }

        formattedTranslations.put(id, value);
    }
}
