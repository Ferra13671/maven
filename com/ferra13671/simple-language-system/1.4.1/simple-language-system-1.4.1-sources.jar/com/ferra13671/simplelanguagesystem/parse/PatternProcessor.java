package com.ferra13671.simplelanguagesystem.parse;

import lombok.experimental.UtilityClass;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@UtilityClass
class PatternProcessor {
    private final Pattern formatPattern = Pattern.compile("\\$\\{id\\h*=\\h*(?<id>[^{}]*)}");
    private final Pattern thisPattern = Pattern.compile("\\$<\\h*this\\h*>");
    private final Pattern parentPattern = Pattern.compile("\\$<\\h*parent\\h*>");

    Map<String, String> processTranslations(Map<TranslationId, String> translations) {
        Map<String, String> processedTranslations = new HashMap<>();

        translations.forEach((id, value) -> process(id, value, translations, processedTranslations));

        return processedTranslations;
    }

    void process(TranslationId id, String value, Map<TranslationId, String> translations, Map<String, String> processedTranslations) {
        if (processedTranslations.containsKey(id.id()))
            return;

        value = patternReplace(value, formatPattern, result -> {
            String fId = result.group("id");
            fId = patternReplace(
                    fId,
                    thisPattern,
                    r -> id.id()
            );
            fId = patternReplace(
                    fId,
                    parentPattern,
                    r -> id.getParent().id()
            );

            TranslationId formatId = new TranslationId(fId);
            if (translations.containsKey(formatId)) {
                if (!processedTranslations.containsKey(formatId.id()))
                    process(formatId, translations.get(formatId), translations, processedTranslations);

                return processedTranslations.get(formatId.id());
            }

            return null;
        });

        processedTranslations.put(id.id(), value);
    }

    String patternReplace(String src, Pattern pattern, Function<MatchResult, String> replacementFunction) {
        Matcher matcher = pattern.matcher(src);
        for (MatchResult result : matcher.results().toList()) {
            String replacement = replacementFunction.apply(result);

            if (replacement != null)
                src = src.replace(result.group(), replacement);
        }

        return src;
    }
}
