package com.ferra13671.simplelanguagesystem.parse;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import lombok.NonNull;
import lombok.experimental.UtilityClass;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

@UtilityClass
public class TranslationsParser {

    public Map<String, String> parse(@NonNull InputStream inputStream) {
        try(InputStreamReader reader = new InputStreamReader(inputStream)) {
            return PatternProcessor.processTranslations(getRawTranslations(
                    JsonParser.parseReader(reader).getAsJsonObject(),
                    new HashMap<>(),
                    new TranslationId("")
            ));
        } catch (Exception e) {
            e.printStackTrace();

            return new HashMap<>();
        }
    }

    public Map<String, String> parse(@NonNull JsonObject jsonObject) {
        return PatternProcessor.processTranslations(getRawTranslations(
                jsonObject,
                new HashMap<>(),
                new TranslationId("")
        ));
    }

    Map<TranslationId, String> getRawTranslations(@NonNull JsonObject jsonObject, @NonNull Map<TranslationId, String> translations, @NonNull TranslationId prefix) {
        jsonObject.asMap().forEach((name, element) -> {
            TranslationId id = new TranslationId(prefix.id().isEmpty() ? name : name.isEmpty() ? prefix.id() : String.join(".", prefix.id(), name));

            if (element instanceof JsonPrimitive primitive && primitive.isString())
                translations.put(id, primitive.getAsString());

            if (element instanceof JsonObject object)
                getRawTranslations(object, translations, id);
        });

        return translations;
    }
}
