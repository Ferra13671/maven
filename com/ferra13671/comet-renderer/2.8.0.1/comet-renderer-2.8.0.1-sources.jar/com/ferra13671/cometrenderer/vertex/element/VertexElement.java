package com.ferra13671.cometrenderer.vertex.element;

import lombok.Getter;
import org.apiguardian.api.API;

/**
 * Объект, представляющий собой структурный элемент формата вершины.
 * Совокупность нескольких таких элементов формата вершины составляют целостный формат вершины.
 */
@Getter
@API(status = API.Status.INTERNAL, since = "1.4")
public class VertexElement {
    /** Айди элемента в формате вершины. **/
    private final int id;
    /** Маска элемента. **/
    private final int mask;
    /** Количество данных в элементе. **/
    private final int count;
    /** Количество данных в элементе после обработки типом элемента. **/
    private final int typeCount;
    /** Размер элемента в байтах. **/
    private final int size;
    /** Тип данных элемента. **/
    private final VertexElementType<?> type;

    /**
     * @param id айди элемента в формате вершины.
     * @param count количество данных в элементе.
     * @param type тип данных элемента.
     */
    public VertexElement(int id, int count, VertexElementType<?> type) {
        type.verify();

        this.id = id;
        this.mask = 1 << this.id;
        this.count = count;
        this.typeCount = count * (type.size() / type.offset());
        this.size = this.typeCount * type.size();
        this.type = type;
    }
}
