package com.ferra13671.cometrenderer.glsl.uniform.uniforms;

import com.ferra13671.cometrenderer.glsl.uniform.GLUniform;
import com.ferra13671.cometrenderer.glsl.uniform.UniformType;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL20;
import org.lwjgl.system.MemoryUtil;

import java.nio.FloatBuffer;

/**
 * Униформа, хранящая в себе параметр в виде 4x4 float матрицы.
 *
 * @see GLUniform
 * @see UniformType
 */
public class Matrix4FGLUniform extends GLUniform {
    /** Буфер, в который будет записываться матрица. **/
    private final FloatBuffer buffer = MemoryUtil.memAllocFloat(16);

    public Matrix4FGLUniform(String name, int location) {
        super(name, location);
    }

    /**
     * Устанавливает матрицу в униформу.
     *
     * @param matrix4f матрица, которая будет записан как параметр в униформу.
     */
    public void set(Matrix4f matrix4f) {
        matrix4f.get(this.buffer);
        this.program.addUpdatedUniform(this);
    }

    @Override
    public void upload() {
        GL20.glUniformMatrix4fv(getLocation(), false, this.buffer);
    }
}
