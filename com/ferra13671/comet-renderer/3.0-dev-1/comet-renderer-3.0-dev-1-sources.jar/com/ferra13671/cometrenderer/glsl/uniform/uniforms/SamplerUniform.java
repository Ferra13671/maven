package com.ferra13671.cometrenderer.glsl.uniform.uniforms;

import com.ferra13671.cometrenderer.State;
import com.ferra13671.cometrenderer.glsl.uniform.GLUniform;
import com.ferra13671.cometrenderer.glsl.uniform.UniformType;
import com.ferra13671.gltextureutils.GlTex;
import lombok.Getter;
import lombok.Setter;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

import java.util.function.BiConsumer;

/**
 * Униформа, хранящая в себе параметр в виде текстуры.
 *
 * @see GLUniform
 * @see UniformType
 */
public class SamplerUniform extends GLUniform {
    /** Айди семплера. **/
    @Getter
    @Setter
    private int samplerId;
    /** Runnable, загружающий параметр в униформу. **/
    private Runnable uploadRunnable = null;

    /**
     * @param name имя униформы.
     * @param location локация униформы в OpenGL.
     */
    public SamplerUniform(String name, int location) {
        super(name, location);
    }

    /**
     * Устанавливает текстуру из GlTex.
     *
     * @param texture GlTex.
     *
     * @see GlTex
     */
    public void set(GlTex texture) {
        this.uploadRunnable = () -> {
            State.TEXTURE.activeTexture(GL13.GL_TEXTURE0 + this.samplerId);
            State.TEXTURE.bindTexture(texture.getTexId());
        };
        this.program.addUpdatedUniform(this);
    }

    /**
     * Устанавливает текстуру при помощи её айди в OpenGL.
     *
     * @param textureId айди текстуры в OpenGL.
     */
    public void set(int textureId) {
        this.uploadRunnable = () -> {
            State.TEXTURE.activeTexture(GL30.GL_TEXTURE0 + this.samplerId);
            State.TEXTURE.bindTexture(textureId);
        };
        this.program.addUpdatedUniform(this);
    }

    /**
     * Устанавливает текстуру при помощи пользовательского установщика и объекта.
     *
     * @param uploadConsumer установщик текстуры.
     * @param texture объект текстуры.
     * @param <T> текстура.
     */
    public <T> void set(BiConsumer<SamplerUniform, T> uploadConsumer, T texture) {
        this.uploadRunnable = () -> uploadConsumer.accept(this, texture);
        this.program.addUpdatedUniform(this);
    }

    @Override
    public void upload() {
        if (this.uploadRunnable != null) {
            GL20.glUniform1i(this.location, getSamplerId());

            this.uploadRunnable.run();
        }
    }
}
