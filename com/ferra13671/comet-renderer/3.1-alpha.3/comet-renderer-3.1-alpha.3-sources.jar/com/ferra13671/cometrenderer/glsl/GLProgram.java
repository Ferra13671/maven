package com.ferra13671.cometrenderer.glsl;

import com.ferra13671.cometrenderer.CometRenderer;
import com.ferra13671.cometrenderer.ErrorHandlers;
import com.ferra13671.cometrenderer.glsl.compiler.CometCompiler;
import com.ferra13671.cometrenderer.glsl.uniform.uniforms.buffer.BufferUniform;
import com.ferra13671.cometrenderer.glsl.uniform.GLUniform;
import com.ferra13671.cometrenderer.glsl.uniform.uniforms.OneTypeGLUniform;
import com.ferra13671.cometrenderer.glsl.uniform.UniformType;
import com.ferra13671.cometrenderer.glsl.uniform.uniforms.SamplerUniform;
import com.ferra13671.cometrenderer.glsl.shader.GLShader;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.apiguardian.api.API;

import java.util.*;
import java.util.function.Consumer;

/**
 * Объект, хранящий в себе скомпилированный набор шейдеров ({@link GLShader}), готовых к использованию для отрисовки вершин в GPU.
 * <p>
 * Основной набор шейдеров в программе: вершинный(Vertex) и фрагментный(Fragment).
 * Есть также дополнительные шейдеры, которые могут входить в программу: геометрический, тесселяционные и compute.
 * <p>
 * Программа также может иметь в себе униформы ({@link GLUniform}), предназначенные для передачи различных параметров для настройки обработки пикселей программой.
 *
 * @see CometCompiler
 */
@API(status = API.Status.MAINTAINED, since = "1.1")
@RequiredArgsConstructor
public class GLProgram implements Program {
    /** Имя программы. **/
    @Getter
    private final String name;
    /** Айди программы в OpenGL. **/
    @Getter
    private final int id;
    /** Фрагменты программы, добавленные в программу. **/
    @API(status = API.Status.DEPRECATED, since = "3.1")
    @Getter
    @Deprecated(forRemoval = true)
    private final Set<GLProgramSnippet> snippets;
    /** Карта всех униформ программы, расположенных по их именам. **/
    private final Map<String, GLUniform> uniformsByName;
    /** Список всех семплеров программы. **/
    private final List<SamplerUniform> samplers;
    private final List<BufferUniform> bufferUniforms;
    /** Список униформ, которые были обновлены. Данный список нужен для того, что бы повторно загружать в GPU только те униформы, которые были обновлены. **/
    private final List<GLUniform> updatedUniforms = new ArrayList<>();

    @Override
    public void close() {
        CometRenderer.getDevice().deleteProgram(getId());

        this.uniformsByName.clear();
        this.samplers.clear();
    }

    /**
     * Устанавливает данную программу в OpenGL как активную в данный момент.
     */
    @Override
    public void bind() {
        CometRenderer.getDevice().getPipelineStateManager().setProgram(getId());

        if (!this.updatedUniforms.isEmpty()) {
            for (GLUniform uniform : this.updatedUniforms)
                uniform.upload();

            this.updatedUniforms.clear();
        }

        if (!this.samplers.isEmpty())
            for (GLUniform sampler : this.samplers)
                sampler.upload();
        if (!this.bufferUniforms.isEmpty())
            for (GLUniform bufferUniform : this.bufferUniforms)
                bufferUniform.upload();
    }

    /**
     * Добавляет в список программы униформу, которая была обновлена.
     * Данный метод должен всегда вызываться в реализации униформы в том случае, когда данные в них были обновлены, что бы изменения были загружены на GPU.
     *
     * @param uniform униформа, которая была обновлена.
     *
     * @see GLUniform
     * @see OneTypeGLUniform
     */
    @API(status = API.Status.INTERNAL)
    public void addUpdatedUniform(GLUniform uniform) {
        this.updatedUniforms.add(uniform);
    }

    /**
     * Возвращает униформу программы с данным именем и типом.
     * Если униформа с данной конфигурацией не существует в программе, то метод вызовет ошибку.
     *
     * @param name имя требуемой униформы.
     * @param type тип требуемой униформы.
     * @param <T> униформа.
     * @return требуемая униформа.
     *
     * @see GLUniform
     * @see UniformType
     */
    @Override
    public <T extends GLUniform> T getUniform(String name, UniformType<T> type) {
        T uniform = getUniformNullable(name, type);
        if (uniform == null)
            ErrorHandlers.onNoSuchUniform(name, this.name);
        return uniform;
    }

    /**
     * Возвращает униформу программы с данным именем и типом.
     * Если униформа с данной конфигурацией не существует в программе, то метод вернет null.
     *
     * @param name имя требуемой униформы.
     * @param type тип требуемой униформы.
     * @param <T> униформа.
     * @return требуемая униформа либо null, если таковая не была найдена.
     *
     * @see GLUniform
     * @see UniformType
     */
    @Override
    public <T extends GLUniform> T getUniformNullable(String name, UniformType<T> type) {
        return (T) this.uniformsByName.get(name);
    }

    /**
     * Если требуемая униформа существует в программе, то будет выполнен данный метод с ней.
     *
     * @param name имя требуемой униформы.
     * @param type тип требуемой униформы.
     * @param consumer метод, который выполнится в том случае, если требуемая униформа существует в программе.
     * @param <T> униформа.
     *
     * @see GLUniform
     * @see UniformType
     */
    @Override
    public <T extends GLUniform> void consumeIfUniformPresent(String name, UniformType<T> type, Consumer<T> consumer) {
        T uniform = getUniformNullable(name, type);
        if (uniform != null)
            consumer.accept(uniform);
    }

    /**
     * Возвращает семплер программы с данным айди.
     * Если семплер с данным айди не существует в программе, то метод вызовет ошибку.
     *
     * @param samplerId айди требуемого семплера.
     * @return требуемый семплер.
     *
     * @see SamplerUniform
     */
    @Override
    public SamplerUniform getSampler(int samplerId) {
        SamplerUniform sampler = getSamplerNullable(samplerId);
        if (sampler == null)
            ErrorHandlers.onNoSuchUniform("Sampler[" + samplerId + "]", this.name);
        return sampler;
    }

    /**
     * Возвращает семплер программы с данным айди.
     * Если семплер с данным айди не существует в программе, то метод вернет null.
     *
     * @param samplerId айди требуемого семплера.
     * @return требуемый семплер либо null, если такового не было найдено.
     *
     * @see SamplerUniform
     */
    @Override
    public SamplerUniform getSamplerNullable(int samplerId) {
        return samplerId < 0 || samplerId > this.samplers.size() - 1 ? null : this.samplers.get(samplerId);
    }

    /**
     * Если требуемый семплер существует в программе, то будет выполнен данный метод с ним.
     *
     * @param samplerId айди требуемого семплера.
     * @param consumer метод, который выполнится в том случае, если требуемый семплер существует в программе.
     *
     * @see SamplerUniform
     */
    @Override
    public void consumerIfSamplerPresent(int samplerId, Consumer<SamplerUniform> consumer) {
        SamplerUniform sampler = getSamplerNullable(samplerId);
        if (sampler != null)
            consumer.accept(sampler);
    }

    public static GLProgramBuilder builder(GLProgramSnippet... snippets) {
        return new GLProgramBuilder(snippets);
    }
}