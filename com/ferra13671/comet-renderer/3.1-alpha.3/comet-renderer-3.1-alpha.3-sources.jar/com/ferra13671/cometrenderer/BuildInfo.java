
package com.ferra13671.cometrenderer;

import org.apiguardian.api.API;

@API(status = API.Status.INTERNAL, since = "3.1")
final class BuildInfo {
    public static final String VERSION = "3.1-alpha.3";
}
