package com.ferra13671.cometrenderer.stencil;

import com.ferra13671.cometrenderer.utils.CompareFunction;
import com.ferra13671.cometrenderer.utils.ColorMask;
import lombok.Builder;
import org.apiguardian.api.API;

@Builder
@API(status = API.Status.EXPERIMENTAL, since = "2.9")
public record StencilInfo(Boolean stencilMask, Boolean depthMask, ColorMask colorMask, StencilFunction func, StencilOp op) {
    public static final StencilInfo WRITE = StencilInfo.builder()
            .stencilMask(true)
            .depthMask(false)
            .colorMask(new ColorMask(false, false, false, false))
            .func(new StencilFunction(CompareFunction.ALWAYS, 1, 255))
            .op(new StencilOp(StencilOpAction.KEEP, StencilOpAction.KEEP, StencilOpAction.REPLACE))
            .build();
    public static final StencilInfo READ = StencilInfo.builder()
            .stencilMask(false)
            .depthMask(true)
            .colorMask(new ColorMask(true, true, true, true))
            .func(new StencilFunction(CompareFunction.EQUAL, 1, 255))
            .op(new StencilOp(StencilOpAction.KEEP, StencilOpAction.KEEP, StencilOpAction.KEEP))
            .build();
    public static final StencilInfo INVERTED_READ = StencilInfo.builder()
            .stencilMask(false)
            .depthMask(true)
            .colorMask(new ColorMask(true, true, true, true))
            .func(new StencilFunction(CompareFunction.EQUAL, 0, 255))
            .op(new StencilOp(StencilOpAction.KEEP, StencilOpAction.KEEP, StencilOpAction.KEEP))
            .build();
}
