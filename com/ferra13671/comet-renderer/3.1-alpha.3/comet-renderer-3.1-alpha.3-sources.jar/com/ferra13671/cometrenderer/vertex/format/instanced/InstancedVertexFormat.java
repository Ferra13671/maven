package com.ferra13671.cometrenderer.vertex.format.instanced;

import com.ferra13671.cometrenderer.CometRenderer;
import com.ferra13671.cometrenderer.ErrorHandlers;
import com.ferra13671.cometrenderer.vertex.format.VertexFormat;
import com.ferra13671.cometrenderer.vertex.format.VertexFormatType;
import lombok.Getter;
import lombok.Setter;
import org.apiguardian.api.API;

import java.io.Closeable;
import java.util.function.Supplier;

@API(status = API.Status.EXPERIMENTAL, since = "3.1")
@Getter
@Setter
public class InstancedVertexFormat implements Closeable {
    private final VertexFormat perVertexFormat;
    private final VertexFormat perInstanceFormat;

    private InstancedVertexFormatBuffer buffer = null;

    public InstancedVertexFormat(VertexFormat perVertexFormat, VertexFormat perInstanceFormat) {
        if (perVertexFormat.getType() != VertexFormatType.PerVertex)
            ErrorHandlers.onWrongVertexFormatType(perVertexFormat.getType(), VertexFormatType.PerVertex);
        if (perInstanceFormat.getType() != VertexFormatType.PerInstance)
            ErrorHandlers.onWrongVertexFormatType(perInstanceFormat.getType(), VertexFormatType.PerInstance);

        this.perVertexFormat = perVertexFormat;
        this.perInstanceFormat = perInstanceFormat;
    }

    public InstancedVertexFormatBuffer getOrCreateBuffer(Supplier<InstancedVertexFormatBuffer> supplier) {
        if (this.buffer == null)
            this.buffer = supplier.get();

        return this.buffer;
    }

    @Override
    public void close() {
        if (this.buffer != null) {
            CometRenderer.getDevice().deleteVertexArray(this.buffer.getGlId());

            this.buffer = null;
        }
    }
}
