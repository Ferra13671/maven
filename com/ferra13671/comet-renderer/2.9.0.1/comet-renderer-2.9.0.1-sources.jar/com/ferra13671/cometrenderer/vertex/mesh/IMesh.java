package com.ferra13671.cometrenderer.vertex.mesh;

import com.ferra13671.cometrenderer.buffer.GpuBuffer;
import com.ferra13671.cometrenderer.vertex.DrawMode;
import com.ferra13671.cometrenderer.vertex.format.VertexFormat;
import org.apiguardian.api.API;

/**
 * Объект, хранящий в себе буффер вершин и различную информацию для него.
 */
@API(status = API.Status.MAINTAINED, since = "1.7")
public interface IMesh extends AutoCloseable {

    /**
     * Возвращает количество вершин для буффера вершин.
     *
     * @return количество вершин для буффера вершин.
     */
    int getVertexCount();

    /**
     * Возвращает количество индексов для буффера индексов.
     *
     * @return количество индексов для буффера индексов.
     */
    int getIndexCount();

    /**
     * Возвращает буффер вершин.
     *
     * @return буффер вершин.
     */
    GpuBuffer getVertexBuffer();

    /**
     * Возвращает тип отрисовки вершин.
     *
     * @return тип отрисовки вершин.
     */
    DrawMode getDrawMode();

    /**
     * Возвращает формат вершин.
     *
     * @return формат вершин.
     */
    VertexFormat getVertexFormat();

    /**
     * Закрывает меш.
     */
    @Override
    void close();
}
