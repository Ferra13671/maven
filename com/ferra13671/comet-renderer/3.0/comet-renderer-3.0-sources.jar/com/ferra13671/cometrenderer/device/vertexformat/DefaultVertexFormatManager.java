package com.ferra13671.cometrenderer.device.vertexformat;

import com.ferra13671.cometrenderer.CometRenderer;
import com.ferra13671.cometrenderer.ErrorHandlers;
import com.ferra13671.cometrenderer.buffer.BufferTarget;
import com.ferra13671.cometrenderer.buffer.GpuBuffer;
import com.ferra13671.cometrenderer.vertex.element.VertexElement;
import com.ferra13671.cometrenderer.vertex.format.VertexFormat;
import com.ferra13671.cometrenderer.vertex.format.VertexFormatBuffer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;

public class DefaultVertexFormatManager implements VertexFormatManager {

    @Override
    public void applyFormatToBuffer(GpuBuffer vertexBuffer, VertexFormat vertexFormat) {
        if (vertexBuffer.getTarget() != BufferTarget.ARRAY_BUFFER)
            ErrorHandlers.onWrongBufferTarget(vertexBuffer.getTarget().glId, BufferTarget.ARRAY_BUFFER.glId);

        VertexFormatBuffer vertexFormatBuffer = vertexFormat.getOrCreateBuffer(() -> createVertexFormatBuffer(vertexFormat));

        GL30.glBindVertexArray(vertexFormatBuffer.getGlId());
        if (vertexFormatBuffer.getBuffer() != vertexBuffer) {
            vertexBuffer.bind();
            vertexFormatBuffer.setBuffer(vertexBuffer);
            setupBuffer(vertexFormat, false);
        }
    }

    private VertexFormatBuffer createVertexFormatBuffer(VertexFormat vertexFormat) {
        int i = CometRenderer.getDevice().createVertexArray();
        GL30.glBindVertexArray(i);
        setupBuffer(vertexFormat, true);
        return new VertexFormatBuffer(i, vertexFormat);
    }

    private void setupBuffer(VertexFormat format, boolean vbaIsNew) {
        int i = format.getVertexSize();
        VertexElement[] elements = format.getVertexElements();

        for (int j = 0; j < elements.length; j++) {
            VertexElement vertexElement = elements[j];
            if (vbaIsNew)
                GL30.glEnableVertexAttribArray(j);

            if (vertexElement.getType().glId() == GL11.GL_FLOAT) {
                GL30.glVertexAttribPointer(
                        j, vertexElement.getTypeCount(), vertexElement.getType().glId(), false, i, format.getElementOffset(vertexElement)
                );
            } else {
                GL30.glVertexAttribIPointer(j, vertexElement.getTypeCount(), vertexElement.getType().glId(), i, format.getElementOffset(vertexElement));
            }
        }
    }
}
