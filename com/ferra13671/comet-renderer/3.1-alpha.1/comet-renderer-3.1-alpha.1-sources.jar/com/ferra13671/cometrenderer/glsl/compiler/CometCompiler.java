package com.ferra13671.cometrenderer.glsl.compiler;

import com.ferra13671.cometrenderer.CometRenderer;
import com.ferra13671.cometrenderer.CometTags;
import com.ferra13671.cometrenderer.ErrorHandlers;
import com.ferra13671.cometrenderer.glsl.uniform.GLUniform;
import com.ferra13671.cometrenderer.glsl.uniform.uniforms.buffer.BufferUniform;
import com.ferra13671.cometrenderer.glsl.uniform.uniforms.SamplerUniform;
import com.ferra13671.cometrenderer.utils.tag.Registry;
import com.ferra13671.cometrenderer.glsl.GLProgram;
import com.ferra13671.cometrenderer.glsl.shader.GLShader;
import com.ferra13671.cometrenderer.glsl.shader.ShaderType;
import com.ferra13671.cometrenderer.glsl.uniform.UniformType;
import com.ferra13671.cometrenderer.utils.tag.Tag;
import lombok.NonNull;
import lombok.experimental.UtilityClass;
import org.apiguardian.api.API;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL31;

import java.util.*;
import java.util.regex.Pattern;

@API(status = API.Status.EXPERIMENTAL, since = "1.3")
@UtilityClass
public class CometCompiler {
    private final Map<String, CompilerExtension> extensions = new LinkedHashMap<>();
    public final String DEFAULT_GLSL_FILE_ENTRY = "DEFAULT";

    public void addExtensions(@NonNull CompilerExtension... extensions) {
        for (CompilerExtension extension : extensions) {
            if (CometCompiler.extensions.containsKey(extension.getName()))
                ErrorHandlers.onDoubleCompilerExtensionAddition(extension.getName());

            CometCompiler.extensions.put(extension.getName(), extension);
        }
    }

    public Optional<CompilerExtension> getExtension(@NonNull String name) {
        return Optional.ofNullable(extensions.get(name));
    }

    public Collection<CompilerExtension> getExtensions() {
        return extensions.values();
    }

    @API(status = API.Status.INTERNAL)
    public GLProgram compileProgram(@NonNull Registry registry) {
        String name = registry.get(CometTags.NAME).orElseThrow();

        int programId = CometRenderer.getDevice().createProgram();

        Map<ShaderType, GLShader> compiledShaders = registry.get(CometTags.COMPILED_SHADERS).orElseThrow();
        Map<String, UniformType<?>> uniforms = registry.get(CometTags.UNIFORMS).orElseThrow();

        compiledShaders.forEach((type, shader) -> {
            if (shader.registry().contains(CometTags.UNIFORMS))
                uniforms.putAll(shader.registry().get(CometTags.UNIFORMS).orElseThrow());

            GL20.glAttachShader(programId, shader.id());
        });

        Map<String, GLUniform> uniformsByName = new HashMap<>();
        List<SamplerUniform> samplers = new ArrayList<>();
        List<BufferUniform> bufferUniforms = new ArrayList<>();

        GL20.glLinkProgram(programId);
        CompileStatus status = CompileStatus.fromStatusId(GL20.glGetProgrami(programId, GL20.GL_LINK_STATUS));

        if (status != CompileStatus.FAILURE) {
            CometRenderer.getDevice().getPipelineStateManager().setProgram(programId);

            int samplersCount = 0;
            int bufferUniformsCount = 0;

            for (Map.Entry<String, UniformType<?>> uniformEntry : uniforms.entrySet()) {
                GLUniform uniform = uniformEntry.getValue().uniformCreator().apply(
                        uniformEntry.getKey(),
                        GL20.glGetUniformLocation(programId, uniformEntry.getKey())
                );

                if (uniform.getLocation() == -1 && !(uniform instanceof BufferUniform))
                    ErrorHandlers.onNoSuchUniform(uniform.getName(), name);

                uniformsByName.put(uniformEntry.getKey(), uniform);

                if (uniform instanceof SamplerUniform sampler) {
                    samplers.add(sampler);
                    sampler.setUnit(samplersCount);
                    samplersCount++;
                }

                if (uniform instanceof BufferUniform bufferUniform) {
                    bufferUniforms.add(bufferUniform);
                    bufferUniform.setBufferBinding(bufferUniformsCount);
                    GL31.glUniformBlockBinding(programId, bufferUniform.getBufferIndex(), bufferUniformsCount);
                    bufferUniformsCount++;
                }
            }
        } else {
            ErrorHandlers.onCompileProgramError(name, GL20.glGetProgramInfoLog(programId).trim());
        }

        GLProgram program = new GLProgram(
                name,
                programId,
                new HashSet<>(Arrays.asList(registry.get(CometTags.SNIPPETS).orElseThrow())),
                uniformsByName,
                samplers,
                bufferUniforms
        );
        uniformsByName.forEach((s, uniform) -> uniform.setProgram(program));

        return program;
    }

    @NonNull
    @API(status = API.Status.INTERNAL)
    public GLShader compileShader(GLSLFileEntry shaderEntry, ShaderType shaderType, Registry builderRegistry) {
        //Experimental
        Registry shaderRegistry = new Registry();
        if (builderRegistry.contains(CometTags.TAGS_TO_COPY)) {
            for (Tag<?> tag : builderRegistry.get(CometTags.TAGS_TO_COPY).orElseThrow())
                if (builderRegistry.contains(tag))
                    shaderRegistry.copyValue(builderRegistry, tag);
        }

        GLSLFileEntry processedShader = new GLSLFileEntry(shaderEntry);
        processContent(processedShader.getRegistry(), builderRegistry);
        GLSLContent content = processedShader.getRegistry().get(CometTags.CONTENT).orElseThrow();

        int shaderId = CometRenderer.getDevice().createShader(shaderType);

        GL20.glShaderSource(shaderId, content.concatLines());
        GL20.glCompileShader(shaderId);

        CompileStatus status = CompileStatus.fromStatusId(GL20.glGetShaderi(shaderId, GL20.GL_COMPILE_STATUS));
        if (status == CompileStatus.FAILURE) {
            CometRenderer.getLogger().log("\n" + content.concatLines());
            ErrorHandlers.onCompileShaderError(processedShader.getName(), GL20.glGetShaderInfoLog(shaderId).trim());
        }

        return new GLShader(
                processedShader.getName(),
                shaderId,
                shaderType,
                shaderRegistry
        );
    }

    @API(status = API.Status.INTERNAL)
    public void processContent(@NonNull Registry shaderRegistry, @NonNull Registry builderRegistry) {
        removeComments(shaderRegistry);

        RegexCompilerProcessor.processContent(shaderRegistry, builderRegistry);
        for (CompilerExtension extension : getExtensions())
            extension.processCompile(shaderRegistry, builderRegistry);
    }

    @API(status = API.Status.INTERNAL)
    void removeComments(@NonNull Registry glslFileRegistry) {
        GLSLContent content = glslFileRegistry.get(CometTags.CONTENT).orElseThrow();

        content.set(Pattern.compile("//.*", Pattern.MULTILINE).matcher(content.concatLines()).replaceAll(""));
        content.set(Pattern.compile("/\\*[\\s\\S]*\\*/", Pattern.MULTILINE).matcher(content.concatLines()).replaceAll(""));
    }
}