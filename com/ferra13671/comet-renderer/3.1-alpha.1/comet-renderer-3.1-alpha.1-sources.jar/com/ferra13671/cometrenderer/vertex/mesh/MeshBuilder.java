package com.ferra13671.cometrenderer.vertex.mesh;

import com.ferra13671.cometrenderer.ErrorHandlers;
import com.ferra13671.cometrenderer.buffer.allocator.IAllocator;
import com.ferra13671.cometrenderer.utils.Builder;
import com.ferra13671.cometrenderer.vertex.DrawMode;
import com.ferra13671.cometrenderer.vertex.element.VertexElement;
import com.ferra13671.cometrenderer.vertex.element.VertexElementType;
import com.ferra13671.cometrenderer.vertex.format.VertexFormat;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.lwjgl.system.MemoryUtil;

import java.util.stream.Collectors;

/**
 * Основная реализация сборщика меша.
 *
 * @see IMeshBuilder
 * @see Mesh
 */
public class MeshBuilder extends Builder<Mesh> implements IMeshBuilder {
    /** Аллокатор. **/
    private final IAllocator allocator;
    /** Тип отрисовки вершин. **/
    private final DrawMode drawMode;
    /** Формат вершин. **/
    private final VertexFormat vertexFormat;
    /** Размер вершины. **/
    private final int vertexSize;
    /** Массив отступов для элементов вершин. **/
    private final int[] elementOffsets;
    /** Маска полноценной вершины. **/
    private final int requiredMask;
    /** Закрывать аллокатор после сборки меша или нет. **/
    private final boolean closeAllocatorAfterBuild;

    private long vertexPointer = -1L;
    /** Количество вершин в сборщике. **/
    private int vertexCount;
    /** Текущая маска вершины. **/
    private int currentMask;
    /** Закрыт сборщик меша или нет. **/
    private boolean built = false;

    /**
     * @param bufferAllocator аллокатор.
     * @param drawMode тип отрисовки вершин.
     * @param vertexFormat формат вершин.
     * @param closeAllocatorAfterBuild закрывать аллокатор после сборки меша или нет.
     */
    public MeshBuilder(IAllocator bufferAllocator, DrawMode drawMode, VertexFormat vertexFormat, boolean closeAllocatorAfterBuild) {
        super("mesh");
        this.allocator = bufferAllocator;
        this.drawMode = drawMode;
        this.vertexFormat = vertexFormat;
        this.vertexSize = vertexFormat.getVertexSize();
        this.elementOffsets = vertexFormat.getElementOffsets();
        this.requiredMask = vertexFormat.getElementsMask() & ~1;
        this.closeAllocatorAfterBuild = closeAllocatorAfterBuild;
    }

    /**
     * Проверяет, собирается ли меш данным сборщиком или нет.
     * Если нет, то вызывается ошибка.
     */
    private void assertNotBuilt() {
        if (this.built)
            ErrorHandlers.onMeshBuilderAlreadyBuilt();
    }

    @Override
    public Mesh buildNullable() {
        assertNotBuilt();
        assertVertexStructure();
        Mesh mesh = buildInternal();
        if (this.closeAllocatorAfterBuild)
            this.allocator.close();
        else
            this.allocator.clear();
        this.built = true;
        this.vertexPointer = -1L;
        return mesh;
    }

    @Override
    public Mesh build() {
        Mesh mesh = buildNullable();
        if (mesh == null) {
            ErrorHandlers.onEmptyMeshBuilder();
            return null;
        } else {
            return mesh;
        }
    }

    /**
     * Собирает вершины и их элементы в цельный меш.
     *
     * @return цельный меш.
     */
    private Mesh buildInternal() {
        return
            this.vertexCount == 0 ?
                null
                :
                this.allocator.isEmpty() ?
                    null
                    :
                    new Mesh(
                            this.allocator,
                            this.vertexFormat,
                            this.vertexCount,
                            this.drawMode
                    );
    }

    /**
     * Начинает сборку новой вершины.
     *
     * @return адрес новой вершины.
     */
    private long beginVertex() {
        assertNotBuilt();
        assertVertexStructure();

        this.vertexCount++;

        long l = this.allocator.allocate(this.vertexSize);
        this.vertexPointer = l;
        return l;
    }

    private void assertVertexStructure() {
        if (this.vertexCount != 0 && this.currentMask != 0) {
            String string = this.vertexFormat.getElementsFromMask(this.currentMask).map(this.vertexFormat::getElementName).collect(Collectors.joining(", "));
            ErrorHandlers.onBadVertexStructure(string);
        }
    }

    /**
     * Начинает сборку элемента вершины.
     *
     * @param element элемент вершины.
     * @return адрес элемента.
     */
    private long beginElement(VertexElement element) {
        int i = this.currentMask;
        int j = i & ~element.getMask();

        if (j == i) {
            return -1L;
        } else {
            this.currentMask = j;
            long l = this.vertexPointer;

            if (l == -1L) {
                ErrorHandlers.onMeshBuilderNotBuildingVertex();
                return -1L;
            } else {
                return l + this.elementOffsets[element.getId()];
            }
        }
    }

    @Override
    public MeshBuilder vertex(float x, float y, float z) {
        long l = beginVertex() + this.elementOffsets[0];
        this.currentMask = this.requiredMask;
        MemoryUtil.memPutFloat(l, x);
        MemoryUtil.memPutFloat(l + 4L, y);
        MemoryUtil.memPutFloat(l + 8L, z);
        return this;
    }

    @Override
    public MeshBuilder vertex(Matrix4f matrix4f, float x, float y, float z) {
        Vector3f vec = matrix4f.transformPosition(x, y, z, new Vector3f());
        return vertex(vec.x, vec.y, vec.z);
    }

    @Override
    @SafeVarargs
    public final <T> MeshBuilder element(String name, VertexElementType<T> elementType, T... values) {
        long pointer = beginElement(this.vertexFormat.getElement(name));
        if (pointer != -1L)
            elementType.uploadConsumer().accept(pointer, values);

        return this;
    }
}
