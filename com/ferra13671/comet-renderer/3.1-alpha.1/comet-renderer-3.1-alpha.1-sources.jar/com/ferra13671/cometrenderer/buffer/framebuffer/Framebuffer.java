package com.ferra13671.cometrenderer.buffer.framebuffer;

import org.apiguardian.api.API;

@API(status = API.Status.STABLE, since = "2.0")
public interface Framebuffer {

    @API(status = API.Status.MAINTAINED, since = "3.1")
    String getName();

    @API(status = API.Status.MAINTAINED, since = "3.1")
    boolean isUseColor();

    @API(status = API.Status.MAINTAINED, since = "3.1")
    boolean isUseDepth();

    @API(status = API.Status.MAINTAINED, since = "3.1")
    boolean isUseStencil();

    void resize(int width, int height);

    int getWidth();

    int getHeight();

    int getId();

    void bind(boolean setViewport);

    @API(status = API.Status.MAINTAINED, since = "3.0")
    void bindRead();

    @API(status = API.Status.MAINTAINED, since = "3.0")
    void bindDraw(boolean setViewport);

    int getColorTextureId();

    int getDepthAndStencilTextureId();

    void blit(Framebuffer target, boolean copyDepth, boolean copyStencil);

    void blit(int framebufferId, int width, int height, boolean copyDepth, boolean copyStencil);

    void clearColor();

    void clearDepth();

    void clearStencil();

    void clearAll();

    void delete();
}
