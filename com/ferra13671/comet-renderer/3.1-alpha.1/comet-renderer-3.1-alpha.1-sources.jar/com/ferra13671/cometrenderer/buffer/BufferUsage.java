package com.ferra13671.cometrenderer.buffer;

import lombok.AllArgsConstructor;
import org.apiguardian.api.API;
import org.lwjgl.opengl.GL15;

/**
 * Тип использования GPU буффера.
 *
 * @see GpuBuffer
 */
@AllArgsConstructor
@API(status = API.Status.STABLE, since = "1.7.1")
public enum BufferUsage {
    STREAM_DRAW(GL15.GL_STREAM_DRAW),
    STATIC_DRAW(GL15.GL_STATIC_DRAW),
    DYNAMIC_DRAW(GL15.GL_DYNAMIC_DRAW),
    STREAM_READ(GL15.GL_STREAM_READ),
    STATIC_READ(GL15.GL_STATIC_READ),
    DYNAMIC_READ(GL15.GL_DYNAMIC_READ),
    STREAM_COPY(GL15.GL_STREAM_COPY),
    STATIC_COPY(GL15.GL_STATIC_COPY),
    DYNAMIC_COPY(GL15.GL_DYNAMIC_COPY);

    /** Айди типа использования в OpenGL. **/
    public final int glId;
}
