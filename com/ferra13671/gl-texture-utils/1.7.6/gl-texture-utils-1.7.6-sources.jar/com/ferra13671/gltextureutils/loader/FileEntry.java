package com.ferra13671.gltextureutils.loader;

import com.ferra13671.gltextureutils.PathMode;
import org.apiguardian.api.API;

/**
 * An object representing a file path. Used in {@link TextureLoader#FILE_ENTRY} and {@link GifLoader#FILE_ENTRY}.
 *
 * @param path     File path.
 * @param pathMode File path mode.
 */
@API(status = API.Status.MAINTAINED, since = "1.6.3")
public record FileEntry(String path, PathMode pathMode) {
}
