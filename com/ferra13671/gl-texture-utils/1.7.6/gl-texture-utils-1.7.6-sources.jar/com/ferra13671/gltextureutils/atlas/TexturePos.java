package com.ferra13671.gltextureutils.atlas;

import org.apiguardian.api.API;

/**
 * An object that stores the 2D position of a texture.
 */
@API(status = API.Status.MAINTAINED, since = "1.7.4")
public record TexturePos(int x1, int y1, int x2, int y2) {
    /**
     * Normalizes texture 2D position to UV coordinates.
     *
     * @param width  the width to which the texture position should be normalized.
     * @param height the height to which the texture position should be normalized.
     * @return UV coordinates of a texture.
     */
    public TextureBorder normalize(int width, int height) {
        return new TextureBorder(
                (float) this.x1 / width,
                (float) this.y1 / height,
                (float) this.x2 / width,
                (float) this.y2 / height
        );
    }
}
