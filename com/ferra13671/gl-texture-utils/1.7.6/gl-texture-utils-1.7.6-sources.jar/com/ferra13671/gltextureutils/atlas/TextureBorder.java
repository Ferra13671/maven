package com.ferra13671.gltextureutils.atlas;

import org.apiguardian.api.API;

/**
 * An object that stores the UV coordinates of a texture.
 */
@API(status = API.Status.MAINTAINED, since = "1.7.4")
public record TextureBorder(float u1, float v1, float u2, float v2) {
}
