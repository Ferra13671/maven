package com.ferra13671.gltextureutils.atlas;

import com.ferra13671.gltextureutils.GLTexture;
import org.apiguardian.api.API;

import java.util.HashMap;

@API(status = API.Status.INTERNAL, since = "1.7.4")
public record TextureAtlasScheme(int textureWidth, int textureHeight, HashMap<GLTexture, TexturePos> poses) {
}
