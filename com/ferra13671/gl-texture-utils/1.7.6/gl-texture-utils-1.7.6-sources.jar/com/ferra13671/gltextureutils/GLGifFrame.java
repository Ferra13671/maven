package com.ferra13671.gltextureutils;

import org.apiguardian.api.API;

import java.awt.image.BufferedImage;

/**
 * An object representing a gif frame.
 *
 * @param texture Gif frame texture.
 * @param image   Gif frame image.
 * @param delay   Gif frame update delay.
 * @see GLGif
 */
@API(status = API.Status.INTERNAL, since = "1.7")
public record GLGifFrame(GLTexture texture, BufferedImage image, int delay) {
}
