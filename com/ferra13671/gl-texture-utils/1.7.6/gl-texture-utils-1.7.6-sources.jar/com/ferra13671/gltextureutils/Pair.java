package com.ferra13671.gltextureutils;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.apiguardian.api.API;

@Getter
@Setter
@AllArgsConstructor
@API(status = API.Status.INTERNAL, since = "1.7")
public class Pair<A, B> {
    private A left;
    private B right;
}
