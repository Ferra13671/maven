package com.ferra13671.cometrenderer.plugins.bettercompiler.processors;

import com.ferra13671.cometrenderer.CometRenderer;
import com.ferra13671.cometrenderer.CometTags;
import com.ferra13671.cometrenderer.glsl.compiler.CompilerExtension;
import com.ferra13671.cometrenderer.glsl.compiler.GLSLContent;
import com.ferra13671.cometrenderer.glsl.compiler.RegexCompilerExtension;
import com.ferra13671.cometrenderer.plugins.bettercompiler.BetterCompilerTags;
import com.ferra13671.cometrenderer.utils.tag.Registry;
import com.ferra13671.cometrenderer.utils.tag.Tag;
import lombok.Getter;
import lombok.experimental.UtilityClass;
import org.apiguardian.api.API;

import java.util.regex.MatchResult;
import java.util.regex.Pattern;

@API(status = API.Status.INTERNAL, since = "2.5")
@UtilityClass
public class VersionProcessor {
    private final Tag<Boolean> FOUNDED_GLSL_VERSION = new Tag<>("founded-glsl-version");

    final RegexCompilerExtension regexExtension = new RegexCompilerExtension(Pattern.compile("^\\h*#version\\h+.*", Pattern.MULTILINE)) {
        @Override
        public boolean processMatch(MatchResult result, GLSLContent content, Registry glslFileRegistry, Registry builderRegistry) {
            glslFileRegistry.set(FOUNDED_GLSL_VERSION, true);

            String version = result.group().replaceFirst("#version", "").strip();
            if (version.isBlank())
                CometRenderer.getLogger().error(String.format("[better-compiler] Found #version directive without value. [%s]", glslFileRegistry.get(CometTags.NAME).orElseThrow()));

            if (builderRegistry.contains(BetterCompilerTags.GLSL_VERSION)) {
                content.set(content.concatLines().replaceAll(result.group(), "#version ".concat(builderRegistry.get(BetterCompilerTags.GLSL_VERSION).orElseThrow().glslVersion)));
                return false;
            }

            if (version.equals("auto")) {
                content.set(content.concatLines().replaceAll(result.group(), "#version ".concat(CometRenderer.getRegistry().get(CometTags.GL_VERSION).orElseThrow().glslVersion)));
                return false;
            }

            return false;
        }
    };

    @Getter
    private final CompilerExtension extension = new CompilerExtension("better-compiler-version") {

        {
            registerRegexExtensions(regexExtension);
        }

        @Override
        public void processCompile(Registry shaderRegistry, Registry programRegistry) {
            if (!shaderRegistry.contains(FOUNDED_GLSL_VERSION) && programRegistry.contains(BetterCompilerTags.GLSL_VERSION)) {
                GLSLContent content = shaderRegistry.get(CometTags.CONTENT).orElseThrow();

                content.set(
                        "#version "
                                .concat(programRegistry.get(BetterCompilerTags.GLSL_VERSION).orElseThrow().glslVersion)
                                .concat("\n\n")
                                .concat(content.concatLines())
                );
            }
        }
    };
}
